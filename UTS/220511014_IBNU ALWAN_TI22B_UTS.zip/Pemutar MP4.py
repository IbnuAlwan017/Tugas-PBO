import tkinter as tk
from tkinter import filedialog
from tkinter import ttk
from moviepy.editor import VideoFileClip

class VideoPlayerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Pemutar Video    (IBNU ALWAN-220511014-TI22B)")
        self.root.geometry("700x350")
        self.root.configure(bg="#2E3B4E")

        self.video_path = tk.StringVar()

        self.frame = ttk.Frame(root, padding="10", style="TFrame")
        self.frame.grid(column=0, row=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        self.browse_button = ttk.Button(self.frame, text="Pilih Video", command=self.browse_file, style="TButton")
        self.browse_button.grid(column=0, row=0, pady=10, sticky="ew")

        self.path_label = ttk.Label(self.frame, textvariable=self.video_path, style="TLabel")
        self.path_label.grid(column=0, row=1, pady=5, sticky="ew")

        self.play_button = ttk.Button(self.frame, text="Putar", command=self.play_video, style="TButton")
        self.play_button.grid(column=0, row=2, pady=10, sticky="ew")

        self.stop_button = ttk.Button(self.frame, text="Stop", command=self.stop_video, style="TButton")
        self.stop_button.grid(column=0, row=3, pady=10, sticky="ew")

        self.style = ttk.Style()
        self.style.configure("TButton", padding=5, font=('Helvetica', 10), background="#FFD700", foreground="#2E3B4E")
        self.style.configure("TLabel", font=('Helvetica', 10), background="#2E3B4E", foreground="#FFFFFF")
        self.style.configure("TFrame", background="#2E3B4E")

    def browse_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4;*.avi;*.mkv")])
        self.video_path.set(file_path)

    def play_video(self):
        video_file = self.video_path.get()
        video_clip = VideoFileClip(video_file)
        video_clip.preview()

    def stop_video(self):
        pass

if __name__ == "__main__":
    root = tk.Tk()
    app = VideoPlayerApp(root)
    root.mainloop()
