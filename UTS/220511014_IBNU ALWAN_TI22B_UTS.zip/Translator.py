from googletrans import Translator
import tkinter as tk
from tkinter import ttk

class AplikasiPenerjemah:
    def __init__(self, root):
        self.root = root
        self.root.title("Aplikasi Penerjemah   (IBNU ALWAN-220511014-TI22B)")
        self.root.configure(bg="grey")

        self.penerjemah = Translator()

        self.label = tk.Label(root, text="Masukkan teks:", bg="Black", font=("Helvetica", 14), fg="#FFD700", pady=5)
        self.label.grid(row=0, column=0, padx=10, pady=10, sticky="w")

        self.entry = tk.Entry(root, width=40, font=("Helvetica", 12))
        self.entry.grid(row=0, column=1, padx=10, pady=10)

        self.from_lang_label = tk.Label(root, text="Dari Bahasa:", bg="Black", font=("Helvetica", 14), fg="#FFD700", pady=5)
        self.from_lang_label.grid(row=1, column=0, padx=10, pady=10, sticky="w")

        self.from_lang_var = tk.StringVar()
        self.from_lang_combobox = ttk.Combobox(root, textvariable=self.from_lang_var,
                                              values=["Indonesia", "English", "Sundanese", "Javanese"],
                                              font=("Helvetica", 12))
        self.from_lang_combobox.set("Indonesia")
        self.from_lang_combobox["state"] = "readonly"
        self.from_lang_combobox.grid(row=1, column=1, padx=10, pady=10)

        self.to_lang_label = tk.Label(root, text="Ke Bahasa:", bg="Black", font=("Helvetica", 14), fg="#FFD700", pady=5)
        self.to_lang_label.grid(row=2, column=0, padx=10, pady=10, sticky="w")

        self.to_lang_var = tk.StringVar()
        self.to_lang_combobox = ttk.Combobox(root, textvariable=self.to_lang_var,
                                            values=["English", "Sundanese", "Javanese"],
                                            font=("Helvetica", 12))
        self.to_lang_combobox.set("English")
        self.to_lang_combobox["state"] = "readonly"
        self.to_lang_combobox.grid(row=2, column=1, padx=10, pady=10)

        self.translate_button = tk.Button(root, text="Terjemahkan", command=self.terjemahkan_teks, font=("Helvetica", 12),
                                          bg="grey", fg="Black", pady=5)  # Atur warna tombol
        self.translate_button.grid(row=3, column=0, columnspan=2, pady=10)

        self.result_label = tk.Label(root, text="Hasil:", bg="Black", font=("Helvetica", 14), fg="#FFD700", pady=5)
        self.result_label.grid(row=4, column=0, padx=10, pady=10, sticky="w")

        self.result_text = tk.Text(root, height=10, width=40, font=("Helvetica", 12))
        self.result_text.grid(row=4, column=1, padx=10, pady=10)
        self.result_text["state"] = "disabled"

    def terjemahkan_teks(self):
        teks_input = self.entry.get()
        dari_bahasa = self.from_lang_var.get()
        ke_bahasa = self.to_lang_var.get()

        terjemahan = self.penerjemah.translate(teks_input, src=self.kode_bahasa(dari_bahasa), dest=self.kode_bahasa(ke_bahasa))

        self.result_text["state"] = "normal"
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, terjemahan.text)
        self.result_text["state"] = "disabled"

    def kode_bahasa(self, bahasa):
        kode_bahasa_dict = {
            "Indonesia": "id",
            "English": "en",
            "Sundanese": "su",
            "Javanese": "jw"
        }
        return kode_bahasa_dict.get(bahasa, "en")

if __name__ == "__main__":
    root = tk.Tk()
    app = AplikasiPenerjemah(root)
    root.mainloop()
