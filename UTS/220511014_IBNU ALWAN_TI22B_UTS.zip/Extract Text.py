import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
import pytesseract
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

class TextExtractorApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Extract Text dari Gambar (IBNU ALWAN-220511014-TI22B)")
        self.master.geometry("800x800")

        bg_color = "#2E3B4E"
        fg_color = "#FFFFFF"
        self.master.configure(bg=bg_color)
        self.label_font = ("Arial", 14, "bold")
        self.result_font = ("Arial", 12)
        self.result_bg = "#3E4A5F"

        self.create_widgets()

    def create_widgets(self):
        self.title_label = tk.Label(self.master, text="Extract Text dari Gambar", font=("Arial", 18, "bold"), fg="#FFD700", bg="#2E3B4E")
        self.title_label.pack(pady=20)

        self.label = tk.Label(self.master, text="Pilih gambar untuk ekstraksi teks:", font=self.label_font, fg="#FFD700", bg="#2E3B4E")
        self.label.pack(pady=10)

        self.image_path = ""
        self.image_label = tk.Label(self.master, bg="#2E3B4E")
        self.image_label.pack(pady=10)

        self.browse_button = tk.Button(self.master, text="Pilih Gambar", command=self.browse_image, font=("Arial", 12), bg="#FFD700")
        self.browse_button.pack()

        self.extract_button = tk.Button(self.master, text="Ekstrak Teks", command=self.extract_text, font=("Arial", 12), bg="#98FB98")
        self.extract_button.pack(pady=20)

        self.result_text = tk.Text(self.master, height=10, width=80, font=self.result_font, bg=self.result_bg, fg="#FFFFFF")
        self.result_text.pack()

    def browse_image(self):
        file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.png;*.jpg;*.jpeg;*.bmp")])
        if file_path:
            self.image_path = file_path
            image = Image.open(file_path)
            image.thumbnail((250, 250))
            photo = ImageTk.PhotoImage(image)
            self.image_label.config(image=photo)
            self.image_label.image = photo

    def extract_text(self):
        if self.image_path:
            image = Image.open(self.image_path)
            text = pytesseract.image_to_string(image)
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, text)
        else:
            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, "Pilih gambar terlebih dahulu.")

if __name__ == "__main__":
    root = tk.Tk()
    app = TextExtractorApp(root)
    root.mainloop()
