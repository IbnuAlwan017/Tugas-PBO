import tkinter as tk
from tkinter import ttk

class AplikasiKonversiSuhu:
    def __init__(self, master):
        self.master = master
        self.master.title("Konverter Suhu    (IBNU ALWAN-220511014-TI22B)")
        self.top_unit = tk.StringVar(value="Pilih Suhu Awal")
        self.bottom_unit = tk.StringVar(value="Pilih Suhu Akhir")
        self.create_widgets()

    def create_widgets(self):
        self.title_label = tk.Label(self.master, text="Konverter Suhu", font=("Arial", 16, "bold"), bg="#FFD700")
        self.title_label.grid(row=0, column=0, columnspan=3, pady=10, sticky="nsew")

        self.input_entry = tk.Entry(self.master, width=15)
        self.input_entry.grid(row=1, column=1, padx=10, pady=10)

        self.label_unit_top = tk.Label(self.master, textvariable=self.top_unit, bg="#87CEEB")
        self.label_unit_top.grid(row=1, column=0, padx=10, pady=10, columnspan=2, sticky="w")

        self.label_unit_bottom = tk.Label(self.master, textvariable=self.bottom_unit, bg="#87CEEB")
        self.label_unit_bottom.grid(row=1, column=2, padx=10, pady=10, columnspan=2, sticky="e")

        self.label_result = tk.Label(self.master, text="Hasil:", font=("Arial", 12, "bold"), bg="#FFD700")
        self.label_result.grid(row=3, column=0, columnspan=3, padx=10, pady=10, sticky="nsew")

        self.convert_button = tk.Button(self.master, text="Konversi", command=self.convert_temperature, bg="#98FB98")
        self.convert_button.grid(row=4, column=0, columnspan=3, pady=10, sticky="nsew")

        self.unit_menu_options = ["Celsius", "Fahrenheit", "Kelvin", "Reamur"]

        self.unit_menu_top = ttk.Combobox(self.master, textvariable=self.top_unit, values=self.unit_menu_options, state="readonly")
        self.unit_menu_top.grid(row=5, column=0, pady=10, padx=10, sticky="w")

        self.unit_menu_bottom = ttk.Combobox(self.master, textvariable=self.bottom_unit, values=self.unit_menu_options, state="readonly")
        self.unit_menu_bottom.grid(row=5, column=2, pady=10, padx=10, sticky="e")

    def convert_temperature(self):
        try:
            temperature = float(self.input_entry.get())
            result = 0.0

            top_option = self.top_unit.get()
            bottom_option = self.bottom_unit.get()

            if top_option == "Pilih Suhu Awal" or bottom_option == "Pilih Suhu Akhir":
                self.label_result.config(text="Pilih suhu terlebih dahulu.")
                return

            if top_option == bottom_option:
                self.label_result.config(text="Suhu awal dan akhir sama. Pilih konversi yang berbeda.")
                return

            if top_option == "Celsius" and bottom_option == "Fahrenheit":
                result = (temperature * 9/5) + 32
            elif top_option == "Fahrenheit" and bottom_option == "Celsius":
                result = (temperature - 32) * 5/9
            elif top_option == "Celsius" and bottom_option == "Kelvin":
                result = temperature + 273.15
            elif top_option == "Kelvin" and bottom_option == "Celsius":
                result = temperature - 273.15
            elif top_option == "Celsius" and bottom_option == "Reamur":
                result = temperature * 4/5
            elif top_option == "Reamur" and bottom_option == "Celsius":
                result = temperature * 5/4
            elif top_option == "Fahrenheit" and bottom_option == "Kelvin":
                result = (temperature - 32) * 5/9 + 273.15
            elif top_option == "Kelvin" and bottom_option == "Fahrenheit":
                result = (temperature - 273.15) * 9/5 + 32
            elif top_option == "Fahrenheit" and bottom_option == "Reamur":
                result = (temperature - 32) * 4/9
            elif top_option == "Reamur" and bottom_option == "Fahrenheit":
                result = temperature * 9/4 + 32
            elif top_option == "Kelvin" and bottom_option == "Reamur":
                result = (temperature - 273.15) * 4/5
            elif top_option == "Reamur" and bottom_option == "Kelvin":
                result = temperature * 5/4 + 273.15

            result_text = f"Hasil: {result:.2f} {bottom_option}"
            self.label_result.config(text=result_text)
        except ValueError:
            self.label_result.config(text="Input tidak valid. Harap masukkan angka.")

if __name__ == "__main__":
    root = tk.Tk()
    app = AplikasiKonversiSuhu(root)
    root.mainloop()
