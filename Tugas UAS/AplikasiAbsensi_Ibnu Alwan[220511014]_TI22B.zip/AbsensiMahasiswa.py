import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from PIL import Image, ImageTk
from ModulAbsensi import AbsensiDB

class AbsensiMahasiswaApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Aplikasi Absensi Mahasiswa")
        self.db_connection = AbsensiDB()
        self.create_widgets()

    def create_widgets(self):
        # Tambahkan judul "Absensi Mahasiswa" di dalam GUI
        self.judul_frame = tk.Frame(self)
        self.judul_frame.pack(pady=10)

        # Buka gambar
        img = Image.open("judul_absensi.jpg")
        img = img.resize((300, 150))  
        img = ImageTk.PhotoImage(img)

        # Tampilkan gambar di label
        self.judul_label = tk.Label(self.judul_frame, image=img)
        self.judul_label.image = img
        self.judul_label.pack()

        # Tambahkan label untuk teks di bawah gambar
        self.welcome_label = tk.Label(self.judul_frame, text="Welcome, Mahasiswa!\nSilahkan Absen Dulu", font=("Arial", 22))
        self.welcome_label.pack()

        # Tambahkan garis pembatas setelah judul
        self.garis_pembatas_atas = ttk.Separator(self, orient='horizontal')
        self.garis_pembatas_atas.pack(fill='x', padx=10, pady=5)

        # Buat frame untuk input
        self.input_frame = tk.Frame(self)
        self.input_frame.pack(padx=10, pady=10)

        # Buat input field untuk memasukkan "NIM"
        self.nim_label = tk.Label(self.input_frame, text="NIM")
        self.nim_label.grid(row=0, column=0, padx=10, pady=5)

        self.nim_entry = tk.Entry(self.input_frame)
        self.nim_entry.grid(row=0, column=1, padx=10, pady=5)

        # Buat input field untuk memasukkan "Nama"
        self.nama_label = tk.Label(self.input_frame, text="Nama")
        self.nama_label.grid(row=1, column=0, padx=10, pady=5)

        self.nama_entry = tk.Entry(self.input_frame)
        self.nama_entry.grid(row=1, column=1, padx=10, pady=5)

        # Buat input field untuk memasukkan "Jenis Kelamin"
        self.jenis_kelamin_label = tk.Label(self.input_frame, text="Jenis Kelamin")
        self.jenis_kelamin_label.grid(row=2, column=0, padx=10, pady=5)

        self.jenis_kelamin_combobox = ttk.Combobox(self.input_frame, values=["Laki-laki", "Perempuan"], state='readonly')
        self.jenis_kelamin_combobox.grid(row=2, column=1, padx=10, pady=5)

        # Buat input field untuk memasukkan "Matakuliah"
        self.matakuliah_label = tk.Label(self.input_frame, text="Matakuliah")
        self.matakuliah_label.grid(row=3, column=0, padx=10, pady=5)

        self.matakuliah_entry = tk.Entry(self.input_frame)
        self.matakuliah_entry.grid(row=3, column=1, padx=10, pady=5)

        # Buat input field untuk memasukkan "Dosen"
        self.dosen_label = tk.Label(self.input_frame, text="Dosen")
        self.dosen_label.grid(row=4, column=0, padx=10, pady=5)

        self.dosen_entry = tk.Entry(self.input_frame)
        self.dosen_entry.grid(row=4, column=1, padx=10, pady=5)

        # Buat input field untuk "Pertemuan"
        self.pertemuan_label = tk.Label(self.input_frame, text="Pertemuan")
        self.pertemuan_label.grid(row=5, column=0, padx=10, pady=5)

        self.pertemuan_entry = tk.Entry(self.input_frame)
        self.pertemuan_entry.grid(row=5, column=1, padx=10, pady=5)

        # Buat input field untuk "Waktu Mulai"
        self.waktu_mulai_label = tk.Label(self.input_frame, text="Waktu Mulai")
        self.waktu_mulai_label.grid(row=6, column=0, padx=10, pady=5)

        self.waktu_mulai_entry = tk.Entry(self.input_frame)
        self.waktu_mulai_entry.grid(row=6, column=1, padx=10, pady=5)

        # Buat input field untuk "Waktu Selesai"
        self.waktu_selesai_label = tk.Label(self.input_frame, text="Waktu Selesai")
        self.waktu_selesai_label.grid(row=7, column=0, padx=10, pady=5)

        self.waktu_selesai_entry = tk.Entry(self.input_frame)
        self.waktu_selesai_entry.grid(row=7, column=1, padx=10, pady=5)

        # Buat input field untuk "Keterangan"
        self.keterangan_label = tk.Label(self.input_frame, text="Keterangan")
        self.keterangan_label.grid(row=8, column=0, padx=10, pady=5)

        self.keterangan_combobox = ttk.Combobox(self.input_frame, values=["Hadir", "Tidak Hadir", "Izin/Sakit"], state='readonly')
        self.keterangan_combobox.grid(row=8, column=1, padx=10, pady=5)

        # Buat tombol "Submit"
        self.submit_button = tk.Button(self.input_frame, text="Submit", command=self.submit_data, bg="green", fg="white")
        self.submit_button.grid(row=9, columnspan=2, padx=10, pady=10)

    def submit_data(self):
        # Mendapatkan data dari input fields
        nim = self.nim_entry.get().strip()
        nama = self.nama_entry.get().strip()
        jenis_kelamin = self.jenis_kelamin_combobox.get()
        matakuliah = self.matakuliah_entry.get().strip()
        dosen = self.dosen_entry.get().strip()
        pertemuan = self.pertemuan_entry.get().strip()
        waktu_mulai = self.waktu_mulai_entry.get().strip()
        waktu_selesai = self.waktu_selesai_entry.get().strip()
        keterangan = self.keterangan_combobox.get()

        # Memastikan NIM adalah bilangan bulat
        if not nim.isdigit():
            messagebox.showerror("Error", "NIM harus berupa bilangan bulat.")
            return

        # Memastikan pertemuan adalah angka
        if not pertemuan.isdigit():
            messagebox.showerror("Error", "Pertemuan harus berupa angka.")
            return

        # Memeriksa apakah NIM sudah ada dalam data
        if self.db_connection.check_nim_exists(nim):
            messagebox.showerror("Error", "NIM sudah ada dalam data.")
            return

        # Memasukkan data ke dalam tabel
        self.db_connection.insert_data(nim, nama, jenis_kelamin, matakuliah, dosen, pertemuan, waktu_mulai, waktu_selesai, keterangan)
        messagebox.showinfo("Info", "Data berhasil disubmit.")

if __name__ == "__main__":
    app = AbsensiMahasiswaApp()
    app.mainloop()
