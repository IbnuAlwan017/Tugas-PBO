import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from PIL import Image, ImageTk
from ModulAbsensi import AbsensiDB

class AbsensiApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Aplikasi Absensi")
        self.db_connection = AbsensiDB()
        self.create_widgets()
        self.load_data_from_database()  # Memuat data dari database saat program dijalankan
        

    def create_widgets(self):
        # Tambahkan judul "Welcome, Dosen" di dalam GUI
        self.judul_frame = tk.Frame(self)
        self.judul_frame.pack(pady=10)

        # Tampilkan teks "Welcome, Dosen" dalam ukuran besar
        self.judul_label = tk.Label(self.judul_frame, text="Welcome, Dosen", font=("Helvetica", 24))
        self.judul_label.pack()

        # Tambahkan garis pembatas setelah judul
        self.garis_pembatas_atas = ttk.Separator(self, orient='horizontal')
        self.garis_pembatas_atas.pack(fill='x', padx=10, pady=5)

        # Buat frame untuk input
        self.input_frame = tk.Frame(self)
        self.input_frame.pack(side="left", padx=10, pady=10)

        # Buat input field untuk memasukkan "NIM"
        self.nim_label = tk.Label(self.input_frame, text="NIM")
        self.nim_label.grid(row=0, column=0, padx=10, pady=5)

        self.nim_entry = tk.Entry(self.input_frame)
        self.nim_entry.grid(row=0, column=1, padx=10, pady=5)

        # Buat input field untuk memasukkan "Nama"
        self.nama_label = tk.Label(self.input_frame, text="Nama")
        self.nama_label.grid(row=1, column=0, padx=10, pady=5)

        self.nama_entry = tk.Entry(self.input_frame)
        self.nama_entry.grid(row=1, column=1, padx=10, pady=5)

        # Buat input field untuk memasukkan "Jenis Kelamin"
        self.jenis_kelamin_label = tk.Label(self.input_frame, text="Jenis Kelamin")
        self.jenis_kelamin_label.grid(row=2, column=0, padx=10, pady=5)

        self.jenis_kelamin_combobox = ttk.Combobox(self.input_frame, values=["Laki-laki", "Perempuan"], state='readonly')
        self.jenis_kelamin_combobox.grid(row=2, column=1, padx=10, pady=5)

        # Buat input field untuk memasukkan "Matakuliah"
        self.matakuliah_label = tk.Label(self.input_frame, text="Matakuliah")
        self.matakuliah_label.grid(row=3, column=0, padx=10, pady=5)

        self.matakuliah_entry = tk.Entry(self.input_frame)
        self.matakuliah_entry.grid(row=3, column=1, padx=10, pady=5)

        # Buat input field untuk memasukkan "Dosen"
        self.dosen_label = tk.Label(self.input_frame, text="Dosen")
        self.dosen_label.grid(row=4, column=0, padx=10, pady=5)

        self.dosen_entry = tk.Entry(self.input_frame)
        self.dosen_entry.grid(row=4, column=1, padx=10, pady=5)

        # Buat input field untuk memasukkan "Pertemuan"
        self.pertemuan_label = tk.Label(self.input_frame, text="Pertemuan")
        self.pertemuan_label.grid(row=5, column=0, padx=10, pady=5)

        self.pertemuan_entry = tk.Entry(self.input_frame)
        self.pertemuan_entry.grid(row=5, column=1, padx=10, pady=5)

        # Buat input field untuk "Waktu Mulai"
        self.waktu_mulai_label = tk.Label(self.input_frame, text="Waktu Mulai")
        self.waktu_mulai_label.grid(row=6, column=0, padx=10, pady=5)

        self.waktu_mulai_entry = tk.Entry(self.input_frame)
        self.waktu_mulai_entry.grid(row=6, column=1, padx=10, pady=5)

        # Buat input field untuk "Waktu Selesai"
        self.waktu_selesai_label = tk.Label(self.input_frame, text="Waktu Selesai")
        self.waktu_selesai_label.grid(row=7, column=0, padx=10, pady=5)

        self.waktu_selesai_entry = tk.Entry(self.input_frame)
        self.waktu_selesai_entry.grid(row=7, column=1, padx=10, pady=5)

        # Buat input field untuk "Keterangan"
        self.keterangan_label = tk.Label(self.input_frame, text="Keterangan")
        self.keterangan_label.grid(row=8, column=0, padx=10, pady=5)

        self.keterangan_combobox = ttk.Combobox(self.input_frame, values=["Hadir", "Tidak Hadir", "Izin/Sakit"], state='readonly')
        self.keterangan_combobox.grid(row=8, column=1, padx=10, pady=5)

        # Tambahkan garis pembatas antara bagian input dan kolom output serta tombol
        self.garis_pembatas_tengah = ttk.Separator(self, orient='vertical')
        self.garis_pembatas_tengah.pack(side='left', fill='y', padx=10, pady=10)

        # Buat frame untuk tombol
        self.button_frame = tk.Frame(self)
        self.button_frame.pack(side="right", padx=10, pady=10)

        # Buat tombol "Submit" dengan ukuran 3x lebih besar
        self.submit_button = tk.Button(self.button_frame, text="Submit", command=self.submit_data, bg="green", fg="white", width=15)
        self.submit_button.config(height=3)  # Mengatur tinggi tombol menjadi 3 kali lebih besar
        self.submit_button.pack(pady=5)

        # Buat tombol "update" dengan ukuran 3x lebih besar
        self.update_button = tk.Button(self.button_frame, text="Update", command=self.update_data, bg="red", fg="white", width=15)
        self.update_button.config(height=3)  # Mengatur tinggi tombol menjadi 3 kali lebih besar
        self.update_button.pack(pady=5)

        # Buat tombol "Hapus" dengan ukuran 3x lebih besar
        self.hapus_button = tk.Button(self.button_frame, text="Hapus", command=self.hapus_data, bg="orange", fg="white", width=15)
        self.hapus_button.config(height=3)  # Mengatur tinggi tombol menjadi 3 kali lebih besar
        self.hapus_button.pack(pady=5)

        # Buat tabel untuk menampilkan data
        self.data_treeview = ttk.Treeview(self, columns=["id", "NIM", "Nama", "Jenis Kelamin", "Matakuliah", "Dosen", "Pertemuan", "Waktu Mulai", "Waktu Selesai", "Keterangan"])
        self.data_treeview.heading("#0", text="id")  
        self.data_treeview.heading("#1", text="NIM")
        self.data_treeview.heading("#2", text="Nama")
        self.data_treeview.heading("#3", text="Jenis Kelamin")
        self.data_treeview.heading("#4", text="Matakuliah")
        self.data_treeview.heading("#5", text="Dosen")
        self.data_treeview.heading("#6", text="Pertemuan")
        self.data_treeview.heading("#7", text="Waktu Mulai")
        self.data_treeview.heading("#8", text="Waktu Selesai")
        self.data_treeview.heading("#9", text="Keterangan")

        # Menyesuaikan lebar kolom secara manual
        self.data_treeview.column("#0", width=50)
        self.data_treeview.column("#1", width=100)
        self.data_treeview.column("#2", width=150)
        self.data_treeview.column("#3", width=100)
        self.data_treeview.column("#4", width=100)
        self.data_treeview.column("#5", width=100)
        self.data_treeview.column("#6", width=100)
        self.data_treeview.column("#7", width=100)
        self.data_treeview.column("#8", width=100)
        self.data_treeview.column("#9", width=100)

        # Konfigurasi agar kolom data_treeview ikut disesuaikan dengan tampilan fullscreen
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        self.data_treeview.pack(expand=True, fill='both', padx=10, pady=10)

        # Bind event untuk item yang dipilih
        self.data_treeview.bind("<ButtonRelease-1>", self.select_item)
        

    # Fungsi untuk menampilkan notifikasi jika input kosong
    def show_input_error(self):
        messagebox.showerror("Error", "Masukkan data terlebih dahulu.")

    # Fungsi untuk menambahkan data ke dalam tabel saat tombol "Submit" ditekan
    def submit_data(self):
        # Mendapatkan data dari input fields
        nim = self.nim_entry.get().strip()
        nama = self.nama_entry.get().strip()
        jenis_kelamin = self.jenis_kelamin_combobox.get()
        matakuliah = self.matakuliah_entry.get().strip()
        dosen = self.dosen_entry.get().strip()
        pertemuan = self.pertemuan_entry.get().strip()
        waktu_mulai = self.waktu_mulai_entry.get().strip()
        waktu_selesai = self.waktu_selesai_entry.get().strip()
        keterangan = self.keterangan_combobox.get()

        # Memastikan NIM adalah bilangan bulat
        if not nim.isdigit():
            messagebox.showerror("Error", "NIM harus berupa bilangan bulat.")
            return

        # Memasukkan data ke dalam tabel
        self.data_treeview.insert("", "end", text=str(len(self.data_treeview.get_children()) + 1), values=[nim, nama, jenis_kelamin, matakuliah, dosen, pertemuan, waktu_mulai, waktu_selesai, keterangan])

        # Memanggil metode insert_data dari objek AbsensiDB
        self.db_connection.insert_data(nim, nama, jenis_kelamin, matakuliah, dosen, pertemuan, waktu_mulai, waktu_selesai, keterangan)
        
    # Fungsi untuk memperbarui data berdasarkan item yang dipilih
    def update_data(self):
        selected_item = self.data_treeview.selection()
        if selected_item:
            # Mendapatkan data dari input fields
            nim = self.nim_entry.get().strip()
            nama = self.nama_entry.get().strip()
            jenis_kelamin = self.jenis_kelamin_combobox.get()
            matakuliah = self.matakuliah_entry.get().strip()
            dosen = self.dosen_entry.get().strip()
            pertemuan = self.pertemuan_entry.get().strip()
            waktu_mulai = self.waktu_mulai_entry.get().strip()
            waktu_selesai = self.waktu_selesai_entry.get().strip()
            keterangan = self.keterangan_combobox.get()

            # Memastikan NIM adalah bilangan bulat
            if not nim.isdigit():
                messagebox.showerror("Error", "NIM harus berupa bilangan bulat.")
                return

            # Memperbarui data pada item yang dipilih
            self.data_treeview.item(selected_item[0], values=[nim, nama, jenis_kelamin, matakuliah, dosen, pertemuan, waktu_mulai, waktu_selesai, keterangan])

            # Mendapatkan ID dari item yang dipilih
            item_id = self.data_treeview.item(selected_item[0], "text")

            # Memanggil metode update_data dari objek AbsensiDB
            if self.db_connection.update_data(item_id, nim, nama, jenis_kelamin, matakuliah, dosen, pertemuan, waktu_mulai, waktu_selesai, keterangan):
                messagebox.showinfo("Info", "Data berhasil diperbarui.")
            else:
                messagebox.showerror("Error", "Gagal memperbarui data.")

        else:
            messagebox.showinfo("Info", "Pilih data yang ingin diperbarui terlebih dahulu.")

    # Fungsi untuk menghapus data yang dipilih
    def hapus_data(self):
        selected_item = self.data_treeview.selection()
        if selected_item:
            # Mendapatkan ID dari item yang dipilih
            item_id = self.data_treeview.item(selected_item[0], "text")

            # Menghapus item dari Treeview
            self.data_treeview.delete(selected_item)

            # Memanggil metode delete_data dari objek AbsensiDB
            if self.db_connection.delete_data(item_id):
                messagebox.showinfo("Info", "Data berhasil dihapus.")
            else:
                messagebox.showerror("Error", "Gagal menghapus data.")

        else:
            messagebox.showinfo("Info", "Pilih data yang ingin dihapus terlebih dahulu.")

    # Fungsi untuk mengisi input fields dengan data dari item yang dipilih
    def select_item(self, event):
        selected_item = self.data_treeview.focus()
        if selected_item:
            item_data = self.data_treeview.item(selected_item, "values")
            self.nim_entry.delete(0, tk.END)
            self.nim_entry.insert(0, item_data[0])
            self.nama_entry.delete(0, tk.END)
            self.nama_entry.insert(0, item_data[1])
            self.jenis_kelamin_combobox.set(item_data[2])
            self.matakuliah_entry.delete(0, tk.END)
            self.matakuliah_entry.insert(0, item_data[3])
            self.dosen_entry.delete(0, tk.END)
            self.dosen_entry.insert(0, item_data[4])
            self.pertemuan_entry.delete(0, tk.END)
            self.pertemuan_entry.insert(0, item_data[5])
            self.waktu_mulai_entry.delete(0, tk.END)
            self.waktu_mulai_entry.insert(0, item_data[6])
            self.waktu_selesai_entry.delete(0, tk.END)
            self.waktu_selesai_entry.insert(0, item_data[7])
            self.keterangan_combobox.set(item_data[8])

    # Fungsi untuk memuat data dari database dan menampilkannya dalam tabel saat program dijalankan
    def load_data_from_database(self):
        # Mengambil semua data dari database
        all_data = self.db_connection.get_all_data()

        # Memasukkan data ke dalam tabel
        for data in all_data:
            # data[0] adalah id dari data yang diambil dari database
            self.data_treeview.insert("", "end", text=data[0], values=data[1:])

if __name__ == "__main__":
    app = AbsensiApp()
    app.mainloop()
