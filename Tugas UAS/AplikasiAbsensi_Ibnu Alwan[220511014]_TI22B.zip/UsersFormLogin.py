import tkinter as tk
from tkinter import messagebox
import subprocess
from db import DBConnection

class UsersLoginForm:
    def __init__(self, root):
        self.root = root
        self.root.title("Login Form")
        self.root.geometry("300x200")

        # Background color
        self.root.config(bg="#f0f0f0")

        # Font style
        self.label_font = ("Helvetica", 10)
        self.entry_font = ("Helvetica", 10)
        self.button_font = ("Helvetica", 10, "bold")

        # Email label and entry
        self.label_email = tk.Label(self.root, text="Email:", font=self.label_font, bg="#f0f0f0")
        self.label_email.pack()
        self.entry_email = tk.Entry(self.root, font=self.entry_font)
        self.entry_email.pack()

        # Password label and entry
        self.label_password = tk.Label(self.root, text="Password:", font=self.label_font, bg="#f0f0f0")
        self.label_password.pack()
        self.entry_password = tk.Entry(self.root, show="*", font=self.entry_font)
        self.entry_password.pack()

        # Login buttons
        self.button_dosen = tk.Button(self.root, text="Login as Dosen", font=self.button_font, bg="#4CAF50", fg="white", command=self.login_as_dosen)
        self.button_dosen.pack(pady=5)

        self.button_mahasiswa = tk.Button(self.root, text="Login as Mahasiswa", font=self.button_font, bg="#007BFF", fg="white", command=self.login_as_mahasiswa)
        self.button_mahasiswa.pack(pady=5)

    def connect_db(self):
        db_connection = DBConnection()  # Membuat objek DBConnection
        return db_connection.connect()  # Menggunakan metode connect untuk koneksi ke database

    def login_as_dosen(self):
        email = self.entry_email.get()
        password = self.entry_password.get()

        conn = self.connect_db()
        if conn:
            cursor = conn.cursor()
            query = "SELECT * FROM users WHERE email=%s AND password=%s AND level='dosen'"
            cursor.execute(query, (email, password))
            user = cursor.fetchone()
            conn.close()

            if user:
                subprocess.run(["python", "AbsensiDosen.py"])
            else:
                messagebox.showerror("Error", "Invalid email or password")

    def login_as_mahasiswa(self):
        email = self.entry_email.get()
        password = self.entry_password.get()

        conn = self.connect_db()
        if conn:
            cursor = conn.cursor()
            query = "SELECT * FROM users WHERE email=%s AND password=%s AND level='mahasiswa'"
            cursor.execute(query, (email, password))
            user = cursor.fetchone()
            conn.close()

            if user:
                subprocess.run(["python", "AbsensiMahasiswa.py"])
            else:
                messagebox.showerror("Error", "Invalid email or password")

if __name__ == "__main__":
    root = tk.Tk()
    app = UsersLoginForm(root)
    root.mainloop()
