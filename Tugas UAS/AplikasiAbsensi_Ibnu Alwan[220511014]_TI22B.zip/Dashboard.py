import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import subprocess

class Dashboard(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Dashboard")
        self.configure(bg="#f0f0f0")  
        self.absensi_window = None  
        self.create_menu()
        self.create_image_label()

    def create_menu(self):
        menubar = tk.Menu(self, font=("Helvetica", 12))  
        login_menu = tk.Menu(menubar, tearoff=0)
        login_menu.add_command(label="Login", command=self.open_login_form)
        menubar.add_cascade(label="Login", menu=login_menu)

        menubar.add_command(label="Exit", command=self.exit_program)

        self.config(menu=menubar)

    def create_image_label(self):
        img = Image.open("judul_absensi.jpg")
        img = img.resize((300, 150))  # Sesuaikan ukuran gambar
        photo = ImageTk.PhotoImage(img)

        image_label = tk.Label(self, image=photo, bg="#f0f0f0")  
        image_label.image = photo
        image_label.pack(side="bottom", pady=20)  

    def open_login_form(self):
        self.withdraw()  
        subprocess.Popen(["python", "UsersFormLogin.py"])
        self.show_dashboard()  

    def show_absensi_window(self):
        absensi_window = tk.Toplevel(self)  
        absensi_window.title("Absensi Dosen")
        absensi_window.grab_set()  
        absensi_window.transient(self)  
        absensi_window.protocol("WM_DELETE_WINDOW", lambda: self.on_child_close(absensi_window))
        absensi_process = subprocess.Popen(["python", "AbsensiDosen.py"])
        absensi_window.wait_window(absensi_window)  
        self.show_dashboard()  

    def on_child_close(self, child_window):
        child_window.destroy()  

    def exit_program(self):
        if self.absensi_window and self.absensi_window.winfo_exists():
            self.absensi_window.destroy()  
        if messagebox.askokcancel("Exit", "Are you sure you want to exit?"):
            self.destroy()

    def show_dashboard(self):
        self.update()  
        self.deiconify()  

if __name__ == "__main__":
    app = Dashboard()
    app.mainloop()
