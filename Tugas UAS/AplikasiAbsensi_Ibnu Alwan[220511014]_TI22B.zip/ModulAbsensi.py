import mysql.connector

class AbsensiDB:
    def __init__(self):
        self.connect_to_mysql()

    def connect_to_mysql(self):
        try:
            self.connection = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="tugasbesar"
            )
            if self.connection.is_connected():
                print("Connected to MySQL")
                self.cursor = self.connection.cursor()
        except mysql.connector.Error as error:
            print("Failed to connect to MySQL", error)

    def insert_data(self, nim, nama, jenis_kelamin, matakuliah, dosen, pertemuan, waktu_mulai, waktu_selesai, keterangan):
        try:
            sql = "INSERT INTO absensi (nim, nama, jenis_kelamin, matakuliah, dosen, pertemuan, waktu_mulai, waktu_selesai, keterangan) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
            values = (nim, nama, jenis_kelamin, matakuliah, dosen, pertemuan, waktu_mulai, waktu_selesai, keterangan)
            self.cursor.execute(sql, values)
            self.connection.commit()
            print(self.cursor.rowcount, "record inserted.")
            return True
        except mysql.connector.Error as error:
            print("Failed to insert record into absensi table", error)
            return False

    def update_data(self, id, nim, nama, jenis_kelamin, matakuliah, dosen, pertemuan, waktu_mulai, waktu_selesai, keterangan):
        try:
            sql = "UPDATE absensi SET nim=%s, nama=%s, jenis_kelamin=%s, matakuliah=%s, dosen=%s, pertemuan=%s, waktu_mulai=%s, waktu_selesai=%s, keterangan=%s WHERE id=%s"
            values = (nim, nama, jenis_kelamin, matakuliah, dosen, pertemuan, waktu_mulai, waktu_selesai, keterangan, id)
            self.cursor.execute(sql, values)
            self.connection.commit()
            print(self.cursor.rowcount, "record(s) affected")
            return True
        except mysql.connector.Error as error:
            print("Failed to update record in absensi table", error)
            return False

    def delete_data(self, id):
        try:
            sql = "DELETE FROM absensi WHERE id = %s"
            value = (id,)
            self.cursor.execute(sql, value)
            self.connection.commit()
            print(self.cursor.rowcount, "record(s) deleted")
            return True
        except mysql.connector.Error as error:
            print("Failed to delete record from absensi table", error)
            return False

    def get_all_data(self):
        try:
            sql = "SELECT * FROM absensi"
            self.cursor.execute(sql)
            return self.cursor.fetchall()  # Mengembalikan semua data dari database
        except mysql.connector.Error as error:
            print("Failed to fetch data from absensi table", error)
            return []